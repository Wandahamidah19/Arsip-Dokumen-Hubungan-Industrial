<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>DMS - Document Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
body{font-family:'Poppins',sans-serif;background:#f4f7fc;margin:0}
body.login{
background:linear-gradient(135deg,#1e3c72,#2a5298);
height:100vh;display:flex;align-items:center;justify-content:center
}
#loginBox{
background:#fff;padding:40px;border-radius:15px;width:380px;text-align:center;
box-shadow:0 20px 40px rgba(0,0,0,.2)
}
.wrapper{display:flex}
.sidebar{
width:260px;
background:linear-gradient(180deg,#1e3c72,#2a5298);
color:#fff;position:fixed;height:100%;
}
.sidebar h3{text-align:center;padding:25px 10px;font-weight:600}
.sidebar a{
color:#fff;display:block;padding:15px 25px;text-decoration:none;
font-size:14px;transition:.3s
}
.sidebar a i{margin-right:10px}
.sidebar a:hover,.sidebar a.active{
background:rgba(255,255,255,.15);
border-left:4px solid #fff
}
.content{margin-left:260px;padding:35px;width:100%}
.card-box{
background:#fff;padding:25px;border-radius:15px;
box-shadow:0 10px 25px rgba(0,0,0,.08);
margin-bottom:20px
}
.table thead{background:#2a5298;color:#fff}
.btn-primary{background:#2a5298;border:none;border-radius:25px}
.btn-success{border-radius:25px}
.hidden{display:none}
.badge-active{background:#28a745}
.badge-expired{background:#dc3545}
.search-box{margin-bottom:15px}
</style>
</head>

<body class="login">

<div id="loginBox">
<h3><b>Arsip Hubungan Industrial</b></h3><br>
<input id="user" class="form-control" placeholder="Username"><br>
<input id="pass" type="password" class="form-control" placeholder="Password"><br>
<button class="btn btn-primary btn-block" onclick="login()">Login</button>
</div>

<div id="app" class="wrapper hidden">

<div class="sidebar">
<h3><i class="fa fa-folder-open"></i>Arsip Hubungan Industrial</h3>
<a class="active" onclick="showPage('dashboard',event)">
<i class="fa fa-dashboard"></i> Dashboard</a>
<a onclick="showPage('berjalan',event)">
<i class="fa fa-file-text"></i> Dokumen Berjalan</a>
<a onclick="showPage('perizinanExpired',event)">
<i class="fa fa-legal"></i> Perizinan Expired</a>
<a onclick="showPage('perjanjianExpired',event)">
<i class="fa fa-handshake-o"></i> Perjanjian Expired</a>
<a onclick="logout()">
<i class="fa fa-sign-out"></i> Logout</a>
</div>

<div class="content">

<!-- DASHBOARD -->
<div id="dashboardPage">
<div class="card-box">
<h2>Dashboard</h2>
<select id="rangeFilter" class="form-control" style="width:250px" onchange="render()">
<option value="30">Akan Habis 30 Hari</option>
<option value="7">Akan Habis 7 Hari</option>
<option value="0">Overdue</option>
</select>
</div>
<div class="card-box">
<table class="table table-bordered">
<thead>
<tr>
<th>Nama</th>
<th>Kategori</th>
<th>Unit Bisnis</th>
<th>Masa Awal</th>
<th>Masa Akhir</th>
<th>Status</th>
</tr>
</thead>
<tbody id="dashboardBody"></tbody>
</table>
</div>
</div>

<!-- DOKUMEN BERJALAN -->
<div id="berjalanPage" class="hidden">
<div class="card-box">
<h2>Dokumen Berjalan</h2>
<button class="btn btn-primary" onclick="openTambah()">Tambah Dokumen</button>
</div>
<div class="card-box">
<input id="searchBerjalan" class="form-control search-box" placeholder="Search..." onkeyup="render()">
<table class="table table-bordered">
<thead>
<tr>
<th>Nama</th>
<th>Unit</th>
<th>Masa Awal</th>
<th>Masa Akhir</th>
<th>Plant</th>
<th>Vendor</th>
<th>File</th>
<th>Aksi</th>
</tr>
</thead>
<tbody id="berjalanBody"></tbody>
</table>
</div>
</div>

<!-- PERIZINAN -->
<div id="perizinanExpiredPage" class="hidden">
<div class="card-box">
<h2>Perizinan Expired</h2>
<button class="btn btn-primary" onclick="openTambah()">Tambah Dokumen</button>
</div>
<div class="card-box">
<input id="searchPerizinan" class="form-control search-box" placeholder="Search..." onkeyup="render()">
<table class="table table-bordered">
<thead>
<tr>
<th>Nama</th>
<th>Unit</th>
<th>Masa Awal</th>
<th>Masa Akhir</th>
<th>Plant</th>
<th>Vendor</th>
<th>File</th>
<th>Aksi</th>
</tr>
</thead>
<tbody id="perizinanBody"></tbody>
</table>
</div>
</div>

<!-- PERJANJIAN -->
<div id="perjanjianExpiredPage" class="hidden">
<div class="card-box">
<h2>Perjanjian Expired</h2>
<button class="btn btn-primary" onclick="openTambah()">Tambah Dokumen</button>
</div>
<div class="card-box">
<input id="searchPerjanjian" class="form-control search-box" placeholder="Search..." onkeyup="render()">
<table class="table table-bordered">
<thead>
<tr>
<th>Nama</th>
<th>Unit</th>
<th>Masa Awal</th>
<th>Masa Akhir</th>
<th>Plant</th>
<th>Vendor</th>
<th>File</th>
<th>Aksi</th>
</tr>
</thead>
<tbody id="perjanjianBody"></tbody>
</table>
</div>
</div>

</div>
</div>

<!-- MODAL -->
<div class="modal fade" id="tambahModal">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header"><h4>Tambah / Edit Dokumen</h4></div>
<div class="modal-body">

<input id="namaDok" class="form-control" placeholder="Nama Dokumen"><br>

<select id="kategoriDok" class="form-control">
<option value="Perizinan">Perizinan</option>
<option value="Perjanjian">Perjanjian</option>
</select><br>

<input id="unitDok" class="form-control" placeholder="Unit Bisnis"><br>

<label>Masa Berlaku Awal</label>
<input type="date" id="tglAwal" class="form-control"><br>

<label>Masa Berlaku Akhir</label>
<input type="date" id="tglAkhir" class="form-control"><br>

<input id="plantDok" class="form-control" placeholder="Plant"><br>
<input id="vendorDok" class="form-control" placeholder="Vendor"><br>

<input type="file" id="fileDok" class="form-control"><br>

<button class="btn btn-success btn-block" onclick="submitDokumen()">Simpan</button>

</div>
</div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js"></script>

<script>
const admin={u:'admin',p:'admin123'};
let dokumenList=JSON.parse(localStorage.getItem("dokumenList"))||[];
let editIndex=null;
let defaultKategori=null;

function saveData(){
localStorage.setItem("dokumenList",JSON.stringify(dokumenList));
}

function login(){
if($('#user').val()===admin.u && $('#pass').val()===admin.p){
$('body').removeClass('login');
$('#loginBox').hide();
$('#app').removeClass('hidden');
render();
}else alert('Login salah');
}

function logout(){location.reload();}

function showPage(page,e){
$('.content>div').addClass('hidden');
$('#'+page+'Page').removeClass('hidden');
$('.sidebar a').removeClass('active');
if(e)e.target.classList.add('active');
}

function openTambah(index=null,kategori=null){
editIndex=index;
defaultKategori=kategori;

if(index!==null){
let d=dokumenList[index];
$('#namaDok').val(d.nama);
$('#kategoriDok').val(d.kategori);
$('#unitDok').val(d.unit);
$('#tglAwal').val(d.tglAwal);
$('#tglAkhir').val(d.tglAkhir);
$('#plantDok').val(d.plant);
$('#vendorDok').val(d.vendor);
}else{
$('#tambahModal input').val('');
if(defaultKategori){
$('#kategoriDok').val(defaultKategori);
}
}

$('#tambahModal').modal('show');
}

function submitDokumen(){

let fileInput = document.getElementById('fileDok');

// VALIDASI WAJIB ISI
if(!$('#namaDok').val() || !$('#tglAwal').val() || !$('#tglAkhir').val()){
alert("Nama dan tanggal wajib diisi!");
return;
}

// DISABLE BUTTON SUPAYA TIDAK DOUBLE CLICK
$('.btn-success').prop('disabled',true).text('Menyimpan...');

if(fileInput.files.length > 0){

let reader = new FileReader();

reader.onload = function(e){
saveDocument(e.target.result);
$('.btn-success').prop('disabled',false).text('Simpan');
};

reader.onerror = function(){
alert("Gagal membaca file!");
$('.btn-success').prop('disabled',false).text('Simpan');
};

reader.readAsDataURL(fileInput.files[0]);

}else{

// kalau tidak upload file baru
let existingFile = (editIndex !== null) ? dokumenList[editIndex].file : null;
saveDocument(existingFile);
$('.btn-success').prop('disabled',false).text('Simpan');

}
}


function saveDocument(fileData){
let data={
nama:$('#namaDok').val(),
kategori:$('#kategoriDok').val(),
unit:$('#unitDok').val(),
tglAwal:$('#tglAwal').val(),
tglAkhir:$('#tglAkhir').val(),
plant:$('#plantDok').val(),
vendor:$('#vendorDok').val(),
file:fileData
};

if(editIndex===null){
dokumenList.push(data);
}else{
dokumenList[editIndex]=data;
}

saveData();
$('#tambahModal').modal('hide');
render();
}

function hapus(i){
if(confirm("Yakin hapus?")){
dokumenList.splice(i,1);
saveData();
render();
}
}

function render(){

let today=new Date();
dokumenList.forEach(d=>{
let end=new Date(d.tglAkhir);
d.sisa=Math.ceil((end-today)/(1000*60*60*24));
});

let range=parseInt($('#rangeFilter').val()||30);

// DASHBOARD (hanya belum expired)
let dash=dokumenList.filter(d=>d.sisa>=0 && d.sisa<=range);

$('#dashboardBody').html(dash.map(d=>{

let statusText='';
let statusClass='';

if(d.sisa===0){
statusText='Habis Hari Ini';
statusClass='badge-expired';
}else{
statusText='Habis dalam '+d.sisa+' hari';
statusClass='badge-active';
}

return `
<tr>
<td>${d.nama}</td>
<td>${d.kategori}</td>
<td>${d.unit}</td>
<td>${d.tglAwal}</td>
<td>${d.tglAkhir}</td>
<td><span class="label ${statusClass}">${statusText}</span></td>
</tr>`;
}));

// BERJALAN
let s1=$('#searchBerjalan').val()?.toLowerCase()||'';
let berjalan=dokumenList.filter(d=>d.sisa>=0 && d.nama.toLowerCase().includes(s1));

$('#berjalanBody').html(berjalan.map((d,i)=>`
<tr>
<td>${d.nama}</td>
<td>${d.unit}</td>
<td>${d.tglAwal}</td>
<td>${d.tglAkhir}</td>
<td>${d.plant}</td>
<td>${d.vendor}</td>
<td>
${d.file ? `<button class="btn btn-info btn-xs" onclick="openFile(${dokumenList.indexOf(d)})">Lihat</button>` : '-'}
</td>

<td>
<button class="btn btn-xs btn-warning" onclick="openTambah(${i})">Edit</button>
<button class="btn btn-xs btn-danger" onclick="hapus(${i})">Hapus</button>
</td>
</tr>`));

// PERIZINAN EXPIRED
let s2=$('#searchPerizinan').val()?.toLowerCase()||'';
let perizinan=dokumenList.filter(d=>d.kategori==='Perizinan' && d.sisa<0 && d.nama.toLowerCase().includes(s2));

$('#perizinanBody').html(perizinan.map((d,i)=>`
<tr>
<td>${d.nama}</td>
<td>${d.unit}</td>
<td>${d.tglAwal}</td>
<td>${d.tglAkhir}</td>
<td>${d.plant}</td>
<td>${d.vendor}</td>
<td>
${d.file ? `<button class="btn btn-info btn-xs" onclick="openFile(${dokumenList.indexOf(d)})">Lihat</button>` : '-'}
</td>

<td>
<button class="btn btn-xs btn-warning" onclick="openTambah(${i})">Edit</button>
<button class="btn btn-xs btn-danger" onclick="hapus(${i})">Hapus</button>
</td>
</tr>`));

// PERJANJIAN EXPIRED
let s3=$('#searchPerjanjian').val()?.toLowerCase()||'';
let perjanjian=dokumenList.filter(d=>d.kategori==='Perjanjian' && d.sisa<0 && d.nama.toLowerCase().includes(s3));

$('#perjanjianBody').html(perjanjian.map((d,i)=>`
<tr>
<td>${d.nama}</td>
<td>${d.unit}</td>
<td>${d.tglAwal}</td>
<td>${d.tglAkhir}</td>
<td>${d.plant}</td>
<td>${d.vendor}</td>
<td>
${d.file ? `<button class="btn btn-info btn-xs" onclick="openFile(${dokumenList.indexOf(d)})">Lihat</button>` : '-'}
</td>

<td>
<button class="btn btn-xs btn-warning" onclick="openTambah(${i})">Edit</button>
<button class="btn btn-xs btn-danger" onclick="hapus(${i})">Hapus</button>
</td>
</tr>`));

}
function openFile(index){

let fileData = dokumenList[index].file;

if(!fileData){
alert("File tidak ditemukan");
return;
}

// pisahkan metadata & base64
let arr = fileData.split(',');
let mime = arr[0].match(/:(.*?);/)[1];
let bstr = atob(arr[1]);
let n = bstr.length;
let u8arr = new Uint8Array(n);

while(n--){
u8arr[n] = bstr.charCodeAt(n);
}

let blob = new Blob([u8arr], {type:mime});
let url = URL.createObjectURL(blob);

window.open(url, '_blank');
}

</script>
